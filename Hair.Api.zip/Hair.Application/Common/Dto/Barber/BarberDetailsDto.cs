﻿namespace Hair.Application.Common.Dto.Barber;

public record BarberDetailsDto(string BarberName, string CompanyName);