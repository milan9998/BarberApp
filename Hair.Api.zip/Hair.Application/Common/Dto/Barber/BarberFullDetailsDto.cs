﻿namespace Hair.Application.Common.Dto.Barber;

public record BarberFullDetailsDto(Guid BarberId ,string BarberName, string CompanyName);
