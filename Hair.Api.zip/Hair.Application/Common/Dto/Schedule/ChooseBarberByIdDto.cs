﻿namespace Hair.Application.Common.Dto.Schedule;

public record ChooseBarberByIdDto(Guid barberId);